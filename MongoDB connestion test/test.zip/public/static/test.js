const input1 = document.querySelector("input[name]");
const btn1 = document.getElementById("btn1");
const endPoint = "/user";

btn1.addEventListner("click", () => {
  console.log("post");
  console.log(data);
});

console.log(input1);
