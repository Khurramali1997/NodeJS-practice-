const url =
  "mongodb+srv://khurrum_ali:K.ali1997@cluster-0-for-express-a.r09h7.mongodb.net/myFirstDatabaseTesting?retryWrites=true&w=majority";

export default url;
